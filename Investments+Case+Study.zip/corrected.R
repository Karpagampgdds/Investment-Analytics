setwd("G:/upgrade/case study")
library(dplyr)
library(sqldf)
library(tidyr)

#Load the companies and rounds data (provided on the previous page) into 
#two data frames and name them companies and rounds2 respectively.

d1 <- read.csv("companies.csv")
companies <- as.data.frame.array(d1)
d2 <- read.csv("rounds2.csv")
rounds2 <- as.data.frame(d2)

#How many unique companies are present in rounds2? 

rounds2$company_permalink <- sapply(rounds2$company_permalink, tolower)
unique_in_rounds2 <- nrow(distinct(rounds2,rounds2$company_permalink))
unique_in_rounds2

#How many unique companies are present in companies?

companies$permalink <- sapply(companies$permalink, tolower)

unique_in_companies <-nrow(distinct(companies,companies$permalink))

unique_in_companies


distinct_in_companies <-distinct(companies,companies$permalink)

distinct_in_rounds2 <- distinct(rounds2,rounds2$company_permalink)


distinct_in_companies <- as.data.frame(distinct_in_companies)

distinct_in_rounds2 <- as.data.frame(distinct_in_rounds2)


#Are there any companies in the rounds2 file which are not present in companies? Answer yes or no: Y/N

result <- sqldf('select * from distinct_in_rounds2 EXCEPT select * from distinct_in_companies')

print(result)

# Merge the two data frames so that all variables (columns) in the companies frame are added to the rounds2 data frame.
# Name the merged frame master_frame. How many observations are present in master_frame?

master_frame <- merge(companies,rounds2, by.x = c("permalink"),by.y = c("company_permalink"))

master_frame

# Calculate the average investment amount for each of the four funding types (venture, angel, seed, and private equity)

fund_type_average <- aggregate(master_frame$raised_amount_usd, by=list(master_frame$funding_round_type), FUN=mean,na.rm=TRUE,na.action = na.omit)

fund_type_average


# top English-speaking country, Second English-speaking country, Third English-speaking country


english_countries <- read.csv("english.csv")

english_master_frame <- subset(master_frame,master_frame$country_code %in% (english_countries$country_code))

english_master_frame


# Spark Funds wants to see the top nine countries which have received the highest total funding (across ALL sectors for the chosen investment type)


country_wise_investment <- aggregate(english_master_frame$raised_amount_usd, by=list(english_master_frame$country_code), FUN=sum, na.rm=TRUE, na.a=NULL)

country_wise_investment <- country_wise_investment[order(-country_wise_investment$x),]

country_wise_investment



# For the chosen investment type, make a data frame named top9 with the top nine countries (based on the total investment amount each country has received)

top9 <- head(country_wise_investment,9)

top9

write.csv(top9, "top9.csv")


mapping <- read.csv("mapping.csv")

str(mapping)

# Extract the primary sector of each category list from the category_list column

primary_sector <- distinct(mapping, mapping$category_list)

primary_sector


# Use the mapping file 'mapping.csv' to map each primary sector to one of the eight main sectors 

newdata <- gather(mapping,primary_sector,val,Automotive...Sports : Social..Finance..Analytics..Advertising )

newdata <- newdata[!(newdata$val==0),]

newdata


# Code for a merged data frame with each primary sector mapped to its main sector 
# (the primary sector should be present in a separate column).

master_frame_merged <- merge(master_frame,newdata, by="category_list")

master_frame_merged
write.csv(master_frame_merged, "master_frame_merged.csv")

# Create three separate data frames D1, D2 and D3 for each of the three countries containing the observations of funding type FT falling within the 5-15 million USD range. 

D1 <- subset(master_frame_merged, master_frame_merged$country_code=="USA" & master_frame_merged$raised_amount_usd >= 5000000 & master_frame_merged$raised_amount_usd<=15000000, na.rm=TRUE,na.action = na.omit)
D1

D2 <- subset(master_frame_merged, master_frame_merged$country_code=="GBR" & master_frame_merged$raised_amount_usd >= 5000000 & master_frame_merged$raised_amount_usd<=15000000, na.rm=TRUE,na.action = na.omit)
D2

D3 <- subset(master_frame_merged, master_frame_merged$country_code=="IND" & master_frame_merged$raised_amount_usd >= 5000000 & master_frame_merged$raised_amount_usd<=15000000, na.rm=TRUE,na.action = na.omit)
D3


# Total number of investments (count)

total_investments_D1 <- count(D1,D1$country_code)
total_investments_D1

total_investments_D2 <- count(D2,D2$country_code)
total_investments_D2

total_investments_D3 <- count(D3,D3$country_code)
total_investments_D3


# Total amount of investment (USD)

total_amount_investment_D1 <- sum(D1$raised_amount_usd)
total_amount_investment_D1

total_amount_investment_D2 <- sum(D2$raised_amount_usd)
total_amount_investment_D2

total_amount_investment_D3 <- sum(D3$raised_amount_usd)
total_amount_investment_D3


# Top sector (based on count of investments), Second-best sector (based on count of investments),
# Third-best sector (based on count of investments)
# Number of investments in the top sector, Number of investments in the second-best sector, 
# Number of investments in the third-best sector 


top_sector_D1 <- count(D1,D1$primary_sector)
top_sector_D1 <- top_sector_D1[order(-top_sector_D1$n),]
top_sector_D1

top_sector_D2 <- count(D2,D2$primary_sector)
top_sector_D2 <- top_sector_D2[order(-top_sector_D2$n),]
top_sector_D2

top_sector_D3 <- count(D3,D3$primary_sector)
top_sector_D3 <- top_sector_D3[order(-top_sector_D3$n),]
top_sector_D3
# 3,4,5. Top, second, third sector name (based on count of investments)
# 6,7,8. Number of investments in the top,second, third sector (refer to point 3)

top_sector_D1 <- count(D1,D1$primary_sector)
top_sector_D1 <- top_sector_D1[order(-top_sector_D1$n),]
top_sector_D1[1:3,]

top_sector_D2 <- count(D2,D2$primary_sector)
top_sector_D2 <- top_sector_D2[order(-top_sector_D2$n),]
top_sector_D2[1:3,]

top_sector_D3 <- count(D3,D3$primary_sector)
top_sector_D3 <- top_sector_D3[order(-top_sector_D3$n),]
top_sector_D3[1:3,]

# 9. For the top sector count-wise (point 3), which company received the highest investment?

D1_company_received_highest_investment <- subset(D1, D1$primary_sector == "Biotechnology")
D1_company_received_highest_investment <- aggregate(D1_company_received_highest_investment$raised_amount_usd, by=list(D1_company_received_highest_investment$name), FUN=sum, na.rm = TRUE)
D1_company_received_highest_investment <- D1_company_received_highest_investment[order(-D1_company_received_highest_investment$x),]
D1_company_received_highest_investment[1,]

D2_company_received_highest_investment <- subset(D2, D2$primary_sector == "Biotechnology")
D2_company_received_highest_investment <- aggregate(D2_company_received_highest_investment$raised_amount_usd, by=list(D2_company_received_highest_investment$name), FUN=sum, na.rm = TRUE)
D2_company_received_highest_investment <- D2_company_received_highest_investment[order(-D2_company_received_highest_investment$x),]
D2_company_received_highest_investment[1,]

D3_company_received_highest_investment <- subset(D3, D3$primary_sector == "Biotechnology")
D3_company_received_highest_investment <- aggregate(D3_company_received_highest_investment$raised_amount_usd, by=list(D3_company_received_highest_investment$name), FUN=sum, na.rm = TRUE)
D3_company_received_highest_investment <- D3_company_received_highest_investment[order(-D3_company_received_highest_investment$x),]
D3_company_received_highest_investment[1,]

# 10. For the second-best sector count-wise (point 4), which company received the highest investment?

D1_company_received_2nd_bestsector_highest_investment <- subset(D1, D1$primary_sector == "Software")
D1_company_received_2nd_bestsector_highest_investment <- aggregate(D1_company_received_2nd_bestsector_highest_investment$raised_amount_usd, by=list(D1_company_received_2nd_bestsector_highest_investment$name), FUN=sum, na.rm = TRUE)
D1_company_received_2nd_bestsector_highest_investment <- D1_company_received_2nd_bestsector_highest_investment[order(-D1_company_received_2nd_bestsector_highest_investment$x),]
D1_company_received_2nd_bestsector_highest_investment[1,]

D2_company_received_2nd_bestsector_highest_investment <- subset(D2, D2$primary_sector == "Software")
D2_company_received_2nd_bestsector_highest_investment <- aggregate(D2_company_received_2nd_bestsector_highest_investment$raised_amount_usd, by=list(D2_company_received_2nd_bestsector_highest_investment$name), FUN=sum, na.rm = TRUE)
D2_company_received_2nd_bestsector_highest_investment <- D2_company_received_2nd_bestsector_highest_investment[order(-D2_company_received_2nd_bestsector_highest_investment$x),]
D2_company_received_2nd_bestsector_highest_investment[1,]

D3_company_received_2nd_bestsector_highest_investment <- subset(D3, D3$primary_sector == "Software")
D3_company_received_2nd_bestsector_highest_investment <- aggregate(D3_company_received_2nd_bestsector_highest_investment$raised_amount_usd, by=list(D3_company_received_2nd_bestsector_highest_investment$name), FUN=sum, na.rm = TRUE)
D3_company_received_2nd_bestsector_highest_investment <- D3_company_received_2nd_bestsector_highest_investment[order(-D3_company_received_2nd_bestsector_highest_investment$x),]
D3_company_received_2nd_bestsector_highest_investment[1,]


#End of code.